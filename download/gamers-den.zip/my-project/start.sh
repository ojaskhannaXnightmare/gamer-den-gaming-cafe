#!/bin/bash

# Railway startup script for Gamer's Den

echo "🚀 Starting Gamer's Den..."

# Create data directory if it doesn't exist
mkdir -p /app/data

# Set default DATABASE_URL if not set
if [ -z "$DATABASE_URL" ]; then
  export DATABASE_URL="file:/app/data/custom.db"
  echo "📦 Using SQLite database at /app/data/custom.db"
fi

# Run database migrations
echo "📊 Pushing database schema..."
npx prisma db push --skip-generate

# Run seed if database is empty
echo "🌱 Checking if seed is needed..."
node -e "
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
prisma.console.count().then(count => {
  if (count === 0) {
    console.log('Database is empty, seed required');
    process.exit(1);
  } else {
    console.log('Database has data, skipping seed');
    process.exit(0);
  }
}).catch(() => process.exit(1));
" || {
  echo "🌱 Running seed..."
  node -e "
    const { execSync } = require('child_process');
    execSync('npx tsx prisma/seed.ts', { stdio: 'inherit' });
  "
}

# Start the application
echo "🎮 Starting server..."
exec node server.js
