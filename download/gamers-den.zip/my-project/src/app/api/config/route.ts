import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    upiId: process.env.UPI_ID || 'example@upi',
    businessName: process.env.BUSINESS_NAME || "Gamer's Den",
  });
}
