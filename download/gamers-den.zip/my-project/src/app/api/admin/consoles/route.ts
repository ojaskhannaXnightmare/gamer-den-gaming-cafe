import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

async function checkAdmin(request: NextRequest) {
  const sessionId = request.cookies.get('admin_session')?.value;
  if (!sessionId) return false;
  
  const result = await db.$queryRaw`
    SELECT isAdmin FROM User WHERE id = ${sessionId}
  ` as Array<{ isAdmin: boolean }>;
  
  return result && result.length > 0 && result[0].isAdmin;
}

export async function GET(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const consoles = await db.console.findMany({
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ consoles });
  } catch (error) {
    console.error('Error fetching consoles:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const console = await db.console.create({
      data: {
        name: data.name,
        slug: data.slug || data.name.toLowerCase().replace(/\s+/g, '-'),
        description: data.description,
        pricePerHour: parseFloat(data.pricePerHour),
        image: data.image,
        features: data.features ? JSON.stringify(data.features) : null,
        isActive: data.isActive ?? true
      }
    });

    return NextResponse.json({ success: true, console });
  } catch (error) {
    console.error('Error creating console:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id, ...data } = await request.json();
    
    const console = await db.console.update({
      where: { id },
      data: {
        name: data.name,
        slug: data.slug,
        description: data.description,
        pricePerHour: parseFloat(data.pricePerHour),
        image: data.image,
        features: data.features ? JSON.stringify(data.features) : undefined,
        isActive: data.isActive
      }
    });

    return NextResponse.json({ success: true, console });
  } catch (error) {
    console.error('Error updating console:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID required' }, { status: 400 });
    }

    await db.console.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting console:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
