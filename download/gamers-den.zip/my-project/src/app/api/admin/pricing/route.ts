import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

async function checkAdmin(request: NextRequest) {
  const sessionId = request.cookies.get('admin_session')?.value;
  if (!sessionId) return false;
  
  const result = await db.$queryRaw`
    SELECT isAdmin FROM User WHERE id = ${sessionId}
  ` as Array<{ isAdmin: boolean }>;
  
  return result && result.length > 0 && result[0].isAdmin;
}

export async function GET(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const pricing = await db.pricingPackage.findMany({
      orderBy: { price: 'asc' }
    });

    return NextResponse.json({ pricing });
  } catch (error) {
    console.error('Error fetching pricing:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const pricing = await db.pricingPackage.create({
      data: {
        name: data.name,
        description: data.description,
        consoleType: data.consoleType,
        price: parseFloat(data.price),
        duration: parseInt(data.duration),
        discount: data.discount ? parseFloat(data.discount) : null,
        includes: data.includes ? JSON.stringify(data.includes) : null,
        isActive: data.isActive ?? true
      }
    });

    return NextResponse.json({ success: true, pricing });
  } catch (error) {
    console.error('Error creating pricing:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id, ...data } = await request.json();
    
    const pricing = await db.pricingPackage.update({
      where: { id },
      data: {
        name: data.name,
        description: data.description,
        consoleType: data.consoleType,
        price: parseFloat(data.price),
        duration: parseInt(data.duration),
        discount: data.discount ? parseFloat(data.discount) : undefined,
        includes: data.includes ? JSON.stringify(data.includes) : undefined,
        isActive: data.isActive
      }
    });

    return NextResponse.json({ success: true, pricing });
  } catch (error) {
    console.error('Error updating pricing:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID required' }, { status: 400 });
    }

    await db.pricingPackage.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting pricing:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
