import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

async function checkAdmin(request: NextRequest) {
  const sessionId = request.cookies.get('admin_session')?.value;
  if (!sessionId) return false;
  
  const result = await db.$queryRaw`
    SELECT isAdmin FROM User WHERE id = ${sessionId}
  ` as Array<{ isAdmin: boolean }>;
  
  return result && result.length > 0 && result[0].isAdmin;
}

export async function GET(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const events = await db.event.findMany({
      orderBy: { date: 'asc' }
    });

    return NextResponse.json({ events });
  } catch (error) {
    console.error('Error fetching events:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const event = await db.event.create({
      data: {
        title: data.title,
        slug: data.slug || data.title.toLowerCase().replace(/\s+/g, '-'),
        description: data.description,
        gameName: data.gameName,
        date: data.date,
        time: data.time,
        endDate: data.endDate,
        prize: data.prize,
        maxPlayers: data.maxPlayers ? parseInt(data.maxPlayers) : null,
        currentPlayers: data.currentPlayers ? parseInt(data.currentPlayers) : 0,
        price: data.price ? parseFloat(data.price) : 0,
        image: data.image,
        status: data.status || 'upcoming'
      }
    });

    return NextResponse.json({ success: true, event });
  } catch (error) {
    console.error('Error creating event:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id, ...data } = await request.json();
    
    const event = await db.event.update({
      where: { id },
      data: {
        title: data.title,
        slug: data.slug,
        description: data.description,
        gameName: data.gameName,
        date: data.date,
        time: data.time,
        endDate: data.endDate,
        prize: data.prize,
        maxPlayers: data.maxPlayers ? parseInt(data.maxPlayers) : undefined,
        currentPlayers: data.currentPlayers ? parseInt(data.currentPlayers) : undefined,
        price: data.price ? parseFloat(data.price) : undefined,
        image: data.image,
        status: data.status
      }
    });

    return NextResponse.json({ success: true, event });
  } catch (error) {
    console.error('Error updating event:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID required' }, { status: 400 });
    }

    await db.event.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting event:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
