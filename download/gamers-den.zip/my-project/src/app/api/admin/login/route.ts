import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import * as crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json({ error: 'Username and password required' }, { status: 400 });
    }

    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

    const user = await db.$queryRaw`
      SELECT id, username, password, isAdmin FROM User WHERE username = ${username}
    ` as Array<{ id: string; username: string; password: string; isAdmin: boolean }>;

    if (!user || user.length === 0) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    const adminUser = user[0];

    if (adminUser.password !== hashedPassword) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    if (!adminUser.isAdmin) {
      return NextResponse.json({ error: 'Access denied. Admin only.' }, { status: 403 });
    }

    const response = NextResponse.json({ 
      success: true, 
      user: { 
        id: adminUser.id, 
        username: adminUser.username 
      } 
    });

    response.cookies.set('admin_session', adminUser.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7 // 7 days
    });

    return response;
  } catch (error) {
    console.error('Admin login error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
