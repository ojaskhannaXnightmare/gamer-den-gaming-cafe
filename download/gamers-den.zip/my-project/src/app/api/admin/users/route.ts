import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

async function checkAdmin(request: NextRequest) {
  const sessionId = request.cookies.get('admin_session')?.value;
  if (!sessionId) return false;
  
  const result = await db.$queryRaw`
    SELECT isAdmin FROM User WHERE id = ${sessionId}
  ` as Array<{ isAdmin: boolean }>;
  
  return result && result.length > 0 && result[0].isAdmin;
}

export async function GET(request: NextRequest) {
  try {
    const isAdmin = await checkAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const users = await db.$queryRaw`
      SELECT id, username, email, phone, name, createdAt, totalSpent, isAdmin 
      FROM User 
      ORDER BY createdAt DESC
    `;

    const bookingCounts = await db.$queryRaw`
      SELECT userId, COUNT(*) as count FROM Booking GROUP BY userId
    ` as Array<{ userId: string; count: bigint }>;

    const countMap = new Map(bookingCounts.map(b => [b.userId, Number(b.count)]));

    const usersWithBookings = (users as Array<{
      id: string;
      username: string;
      email: string | null;
      phone: string | null;
      name: string | null;
      createdAt: Date;
      totalSpent: number;
      isAdmin: boolean;
    }>).map(user => ({
      ...user,
      bookingCount: countMap.get(user.id) || 0
    }));

    return NextResponse.json({ users: usersWithBookings });
  } catch (error) {
    console.error('Error fetching users:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
